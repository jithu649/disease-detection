import os

import joblib
import numpy as np
import pandas as pd
from flask import Flask, jsonify, render_template, request

from disease_data import DISEASES, pretty

app = Flask(__name__)

MODEL_PATH = os.path.join(os.path.dirname(__file__), "model.joblib")
bundle = joblib.load(MODEL_PATH)
model = bundle["model"]
SYMPTOMS = bundle["symptoms"]


def predict(selected, top_n=3):
    """Return the top_n most likely diseases for the selected symptoms."""
    vector = pd.DataFrame([[1 if s in selected else 0 for s in SYMPTOMS]], columns=SYMPTOMS)
    probs = model.predict_proba(vector)[0]
    order = np.argsort(probs)[::-1][:top_n]
    results = []
    for i in order:
        name = model.classes_[i]
        info = DISEASES.get(name, {})
        results.append({
            "disease": name,
            "confidence": round(float(probs[i]) * 100, 1),
            "description": info.get("description", ""),
            "precautions": info.get("precautions", []),
        })
    return results


@app.route("/")
def index():
    symptoms = [{"id": s, "label": pretty(s)} for s in SYMPTOMS]
    return render_template("index.html", symptoms=symptoms)


@app.route("/predict", methods=["POST"])
def predict_page():
    selected = request.form.getlist("symptoms")
    if len(selected) < 2:
        symptoms = [{"id": s, "label": pretty(s)} for s in SYMPTOMS]
        return render_template(
            "index.html", symptoms=symptoms,
            error="Please select at least 2 symptoms for a meaningful prediction.",
            checked=selected,
        )
    return render_template(
        "result.html",
        results=predict(selected),
        selected=[pretty(s) for s in selected],
    )


@app.route("/api/predict", methods=["POST"])
def predict_api():
    data = request.get_json(silent=True) or {}
    selected = [s for s in data.get("symptoms", []) if s in SYMPTOMS]
    if not selected:
        return jsonify({"error": "Provide a 'symptoms' list."}), 400
    return jsonify({"results": predict(selected)})


if __name__ == "__main__":
    app.run(debug=True)

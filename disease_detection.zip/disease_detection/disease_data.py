"""Symptom-disease knowledge base used to build the training dataset
and to show description / precautions in the result page.

NOTE: This is a small demo knowledge base. For your final project you can
replace it with a real dataset (e.g. the Kaggle "Disease Symptom Prediction"
dataset) -- see train_model.py.
"""

DISEASES = {
    "Common Cold": {
        "symptoms": ["cough", "sneezing", "runny_nose", "sore_throat", "headache", "mild_fever", "fatigue"],
        "description": "A viral infection of the nose and throat that usually clears up by itself.",
        "precautions": ["Rest and drink warm fluids", "Gargle with warm salt water", "Wash hands frequently", "See a doctor if symptoms last more than 10 days"],
    },
    "Influenza (Flu)": {
        "symptoms": ["high_fever", "cough", "body_pain", "headache", "fatigue", "chills", "sore_throat"],
        "description": "A contagious respiratory illness caused by influenza viruses.",
        "precautions": ["Rest and stay hydrated", "Avoid close contact with others", "Take fever-reducing medicine only as advised by a doctor", "Consult a doctor if breathing becomes difficult"],
    },
    "Dengue": {
        "symptoms": ["high_fever", "headache", "joint_pain", "body_pain", "skin_rash", "nausea", "vomiting", "fatigue"],
        "description": "A mosquito-borne viral disease causing high fever and severe body aches.",
        "precautions": ["Consult a doctor immediately", "Drink plenty of fluids", "Use mosquito nets and repellents", "Avoid aspirin/ibuprofen unless a doctor advises"],
    },
    "Malaria": {
        "symptoms": ["high_fever", "chills", "sweating", "headache", "nausea", "vomiting", "body_pain"],
        "description": "A mosquito-borne disease caused by a parasite, with cyclic fever and chills.",
        "precautions": ["Get a blood test as soon as possible", "Take the full prescribed medication course", "Sleep under mosquito nets", "Remove stagnant water around your home"],
    },
    "Typhoid": {
        "symptoms": ["high_fever", "abdominal_pain", "headache", "loss_of_appetite", "fatigue", "diarrhea", "constipation"],
        "description": "A bacterial infection spread through contaminated food and water.",
        "precautions": ["Consult a doctor for antibiotics", "Drink boiled or purified water", "Eat freshly cooked food", "Maintain hand hygiene"],
    },
    "COVID-19": {
        "symptoms": ["high_fever", "cough", "loss_of_smell", "loss_of_taste", "breathlessness", "fatigue", "sore_throat", "body_pain"],
        "description": "A respiratory illness caused by the SARS-CoV-2 virus.",
        "precautions": ["Take a COVID test and isolate", "Wear a mask around others", "Monitor oxygen levels", "Seek emergency care if breathing is difficult"],
    },
    "Gastroenteritis": {
        "symptoms": ["diarrhea", "vomiting", "nausea", "abdominal_pain", "mild_fever", "loss_of_appetite", "fatigue"],
        "description": "Inflammation of the stomach and intestines, usually from infection or food poisoning.",
        "precautions": ["Drink ORS and plenty of fluids", "Eat light, bland food", "Avoid dairy and oily food", "See a doctor if there is blood in stool or severe dehydration"],
    },
    "Migraine": {
        "symptoms": ["severe_headache", "nausea", "vomiting", "light_sensitivity", "blurred_vision", "dizziness"],
        "description": "A neurological condition causing intense, throbbing headaches.",
        "precautions": ["Rest in a quiet, dark room", "Stay hydrated and maintain regular sleep", "Identify and avoid triggers", "Consult a neurologist if attacks are frequent"],
    },
    "Diabetes": {
        "symptoms": ["frequent_urination", "excessive_thirst", "fatigue", "blurred_vision", "weight_loss", "increased_hunger", "slow_healing_wounds"],
        "description": "A chronic condition in which blood sugar levels are too high.",
        "precautions": ["Get blood sugar tests done", "Follow a balanced, low-sugar diet", "Exercise regularly", "Consult a doctor / endocrinologist"],
    },
    "Hypertension": {
        "symptoms": ["headache", "dizziness", "chest_pain", "blurred_vision", "breathlessness", "fatigue"],
        "description": "Persistently high blood pressure that can damage the heart and blood vessels.",
        "precautions": ["Check blood pressure regularly", "Reduce salt intake", "Exercise and manage stress", "Consult a doctor for treatment"],
    },
    "Asthma": {
        "symptoms": ["breathlessness", "wheezing", "cough", "chest_tightness", "fatigue"],
        "description": "A chronic condition in which the airways narrow and swell, making breathing difficult.",
        "precautions": ["Keep your inhaler with you", "Avoid dust, smoke and allergens", "Follow your doctor's asthma action plan", "Seek emergency help for severe breathlessness"],
    },
    "Allergic Rhinitis": {
        "symptoms": ["sneezing", "runny_nose", "itchy_eyes", "watery_eyes", "nasal_congestion", "cough"],
        "description": "An allergic reaction to pollen, dust or pets causing nasal symptoms.",
        "precautions": ["Avoid known allergens", "Keep windows closed during high pollen", "Use a clean mask outdoors", "Ask a doctor about antihistamines"],
    },
    "Urinary Tract Infection": {
        "symptoms": ["burning_urination", "frequent_urination", "abdominal_pain", "mild_fever", "cloudy_urine", "fatigue"],
        "description": "A bacterial infection of the bladder or urinary tract.",
        "precautions": ["Drink plenty of water", "Do not hold urine", "Consult a doctor for antibiotics", "Maintain personal hygiene"],
    },
    "Jaundice": {
        "symptoms": ["yellow_skin", "yellow_eyes", "dark_urine", "fatigue", "abdominal_pain", "loss_of_appetite", "nausea"],
        "description": "Yellowing of the skin and eyes due to high bilirubin, often a sign of liver problems.",
        "precautions": ["See a doctor for liver function tests", "Avoid alcohol and oily food", "Drink safe water", "Rest and eat a light diet"],
    },
    "Pneumonia": {
        "symptoms": ["high_fever", "cough", "breathlessness", "chest_pain", "chills", "fatigue", "sweating"],
        "description": "An infection that inflames the air sacs of one or both lungs.",
        "precautions": ["Consult a doctor promptly", "Complete the prescribed antibiotics", "Rest and drink fluids", "Seek emergency care if breathing worsens"],
    },
}

# Master list of symptoms (derived automatically)
ALL_SYMPTOMS = sorted({s for d in DISEASES.values() for s in d["symptoms"]})


def pretty(symptom: str) -> str:
    """'high_fever' -> 'High fever'"""
    return symptom.replace("_", " ").capitalize()

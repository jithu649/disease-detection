# AI Disease Detection Using Symptoms (Flask website)

## Run
    pip install -r requirements.txt
    python train_model.py     # builds dataset.csv + model.joblib
    python app.py             # open http://127.0.0.1:5000

## Files
- disease_data.py  - symptom/disease knowledge base (replace with a real dataset for final submission)
- train_model.py   - trains the Random Forest model
- app.py           - Flask backend (+ JSON endpoint /api/predict)
- templates/       - base, index (symptom picker), result pages
- static/style.css - styling

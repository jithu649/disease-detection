"""Builds a training dataset from the knowledge base and trains the model.

Run:  python train_model.py

Using a real dataset instead (recommended for the final project):
  1. Download a CSV where each row = one patient, columns = symptoms (0/1)
     plus a 'prognosis' column (e.g. Kaggle "Disease Prediction Using Machine Learning").
  2. Set USE_CSV = "your_file.csv" below.
"""
import random

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split

from disease_data import ALL_SYMPTOMS, DISEASES

USE_CSV = None          # e.g. "Training.csv"
SAMPLES_PER_DISEASE = 300
random.seed(42)
np.random.seed(42)


def build_synthetic_dataset() -> pd.DataFrame:
    rows = []
    for disease, info in DISEASES.items():
        syms = info["symptoms"]
        for _ in range(SAMPLES_PER_DISEASE):
            # a patient shows 60-100% of the disease's symptoms...
            k = random.randint(max(2, int(len(syms) * 0.6)), len(syms))
            chosen = set(random.sample(syms, k))
            # ...plus 0-1 random unrelated symptom (noise)
            if random.random() < 0.3:
                chosen.add(random.choice(ALL_SYMPTOMS))
            row = {s: int(s in chosen) for s in ALL_SYMPTOMS}
            row["prognosis"] = disease
            rows.append(row)
    return pd.DataFrame(rows)


def main():
    df = pd.read_csv(USE_CSV) if USE_CSV else build_synthetic_dataset()
    df.to_csv("dataset.csv", index=False)

    X = df.drop(columns=["prognosis"])
    y = df["prognosis"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    model = RandomForestClassifier(n_estimators=200, random_state=42)
    model.fit(X_train, y_train)

    pred = model.predict(X_test)
    print(f"Accuracy: {accuracy_score(y_test, pred):.3f}")
    print(classification_report(y_test, pred))

    joblib.dump({"model": model, "symptoms": list(X.columns)}, "model.joblib")
    print("Saved model.joblib")


if __name__ == "__main__":
    main()
